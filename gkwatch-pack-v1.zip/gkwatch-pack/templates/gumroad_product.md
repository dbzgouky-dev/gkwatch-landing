# GKWatch — Installe ton propre agent de veille

Prix : 19€ (paiement unique)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

LE PRODUIT

Un pack complet pour installer ton propre GKWatch sur n'importe quel serveur Linux :

✓ Script d'installation automatique (1 commande)
✓ Moteur de veille complet (scan, snapshot, détection)
✓ 10 templates de cibles pré-configurées (prix, blogs, GitHub, emploi...)
✓ Intégration Telegram clé-en-main
✓ Résumés IA des changements (via DeepSeek, optionnel)
✓ Guide d'installation et configuration

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CE QUE TU OBTIENS

📦 Le package complet :

```
gkwatch-pack/
├── core/gkwatch_core.py    → Moteur de veille complet
├── targets/default.json    → 3 cibles prêtes à l'emploi
├── targets/exemples.json   → 10 templates de cibles business
├── install.sh              → Installation automatique
├── .env.template           → Configuration clés API
└── README.md               → Guide complet
```

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CE QUE TU PEUX SURVEILLER

- Pages de prix concurrents
- Blogs / actualités
- APIs REST (JSON, HTML)
- GitHub releases
- Pages d'accueil et landing pages
- Flux RSS / Atom
- Pages d'emploi (détection levée de fonds)
- Pages de changelog / whatsnew
- Profils LinkedIn / Twitter

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

COMMENT ÇA MARCHE

1. Le moteur scanne tes sources à l'intervalle que tu choisis
2. Il compare chaque résultat avec le snapshot précédent (hash SHA256)
3. Si changement détecté, DeepSeek résume ce qui a changé et pourquoi
4. Tu reçois une alerte Telegram claire : quoi, où, pourquoi c'est important

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CE QU'IL TE FAUT

- Un serveur Linux (VPS à 3€/mois, Raspberry Pi, ou ton PC)
- Python 3.8+
- Un compte Telegram (gratuit)
- 5 minutes de configuration

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

GARANTIE

30 jours satisfait ou remboursé. Si le pack ne fonctionne pas comme prévu, je te rembourse sans discuter.
