#!/usr/bin/env bash
# GKWatch — Installation automatique
set -euo pipefail

INSTALL_DIR="${HOME}/gkwatch"
DOWNLOAD_URL="https://buy.stripe.com/eVqfZjekt5jY8Rc7DG2cg02"  # Ton lien Stripe

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  GKWatch — Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Vérifier Python
if ! command -v python3 &>/dev/null; then
    echo "❌ Python3 requis. Installe-le d'abord."
    echo "  Ubuntu/Debian : sudo apt install python3"
    echo "  MacOS : brew install python3"
    exit 1
fi

echo "✅ Python3 $(python3 --version)"

# Créer dossier
mkdir -p "$INSTALL_DIR/data/snapshots" "$INSTALL_DIR/data/logs" "$INSTALL_DIR/targets"
cd "$INSTALL_DIR"

# Vérifier si le pack est déjà présent
if [ ! -f "gkwatch_core.py" ]; then
    echo "📦 Téléchargement de GKWatch..."
    echo ""
    echo "  Pour télécharger le pack :"
    echo "  → $DOWNLOAD_URL"
    echo ""
    echo "  Une fois téléchargé, décompresse-le ici : $INSTALL_DIR"
    echo "  Puis relance ce script."
    exit 0
fi

echo "✅ GKWatch détecté dans $INSTALL_DIR"

# ─── Configuration ────────────────────────────────────────────────────
ENV_FILE="$INSTALL_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
    echo ""
    echo "🔧 Configuration des clés API"
    echo "  (Tu peux aussi créer .env manuellement)"
    echo ""

    # DeepSeek
    read -rp "🧠 Clé API DeepSeek (optionnelle, laisser vide pour ignorer) : " DEEPSEEK_KEY
    # Telegram Bot Token
    read -rp "🤖 Token de ton bot Telegram (obtiens-le sur @BotFather) : " BOT_TOKEN
    # Chat ID
    read -rp "👤 Ton chat ID Telegram (obtiens-le sur @userinfobot) : " CHAT_ID

    cat > "$ENV_FILE" << EOF
# GKWatch — Configuration API
# Copie tes clés ici. Ce fichier est lu automatiquement.

# Optionnel — nécessaire pour les résumés IA des changements
# DEEPSEEK_API_KEY=sk-...

# Obligatoire — ton bot Telegram
TELEGRAM_BOT_TOKEN=${BOT_TOKEN}

# Obligatoire — chat où recevoir les alertes
GK_TELEGRAM_CHAT_ID=${CHAT_ID}
EOF

    echo "✅ Fichier .env créé"
else
    echo "✅ Fichier .env existant"
fi

# ─── Premier lancement ────────────────────────────────────────────────
echo ""
echo "🚀 Initialisation des snapshots (première capture)..."
python3 gkwatch_core.py --init 2>&1 || echo "⚠️  Échec init — vérifie tes cibles dans targets/"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ GKWatch installé !"
echo ""
echo "  Prochaines étapes :"
echo "  1. Édite targets/default.json avec TES URLs à surveiller"
echo "  2. Relance : cd $INSTALL_DIR && source .env && python3 gkwatch_core.py --check-all"
echo "  3. Ajoute un cron pour l'automatisation :"
echo "     crontab -e"
echo "     */30 * * * * cd $INSTALL_DIR && python3 core/gkwatch_core.py --check-all"
echo ""
echo "  Documentation : $INSTALL_DIR/README.md"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
