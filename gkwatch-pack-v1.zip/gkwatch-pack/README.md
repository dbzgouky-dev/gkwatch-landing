# GKWatch — Agent de Veille Universel

Surveillance concurrentielle automatisée. Pas de veille manuelle.
Juste des alertes quand ça change.

## Architecture

```
gkwatch/
├── core/gkwatch_core.py    → Moteur principal
├── gkwatch.json            → Configuration (alertes, stockage)
├── targets/                → Cibles à surveiller (JSON)
│   ├── default.json        → 3 cibles prêtes à l'emploi
│   └── exemples_business.json → 10 templates business
├── data/
│   ├── snapshots/          → États précédents pour comparaison
│   └── logs/               → Journal d'activité
├── templates/
│   ├── gumroad_product.md  → Description produit
│   └── install.sh          → Script d'installation automatique
└── site/
    ├── landing.md          → Page d'accueil
    └── seo_article.md      → Article SEO
```

## Prérequis

- **Python 3.8+** (vérifie avec `python3 --version`)
- **Un bot Telegram** (crée-le sur @BotFather)
- **Ton chat ID Telegram** (obtiens-le sur @userinfobot)
- **Optionnel : une clé API DeepSeek** (pour les résumés IA)

## Installation rapide

```bash
# 1. Décompresse le pack
unzip gkwatch-pack-v1.zip -d ~/gkwatch
cd ~/gkwatch

# 2. Configure tes clés API (édite .env)
# TELEGRAM_BOT_TOKEN, GK_TELEGRAM_CHAT_ID, DEEPSEEK_API_KEY
nano .env

# 3. Initialise les snapshots
source .env && python3 core/gkwatch_core.py --init

# 4. Teste
python3 core/gkwatch_core.py --check-all --dry-run

# 5. Automatise (cron toutes les 30 min)
# crontab -e
# */30 * * * * cd ~/gkwatch && python3 core/gkwatch_core.py --check-all
```

## Utilisation

```bash
# Initialiser les snapshots
python3 core/gkwatch_core.py --init

# Vérifier toutes les cibles
python3 core/gkwatch_core.py --check-all

# Vérifier une cible spécifique
python3 core/gkwatch_core.py --check <target_id>

# Lister les cibles
python3 core/gkwatch_core.py --list

# Test sans alerte
python3 core/gkwatch_core.py --check-all --dry-run
```

## Configuration d'une cible

Ajoute un fichier JSON dans `targets/` :

```json
{
  "targets": [
    {
      "id": "mon-concurrent",
      "name": "Site concurrent",
      "url": "https://concurrent.com/pricing",
      "type": "raw",
      "interval_mins": 1440,
      "summary_prompt": "Résume les changements de prix"
    }
  ]
}
```

- `type` : `"raw"` (HTML), `"json"` (API JSON)
- `selector` : extraction JSON (ex: `$.data.prices`)
- `interval_mins` : fréquence de vérification (défaut: 1440 = 24h)
- `summary_prompt` : instruction pour le résumé DeepSeek

## Variables d'environnement

| Variable | Obligatoire | Description |
|----------|-------------|-------------|
| `DEEPSEEK_API_KEY` | Non | Clé API DeepSeek (résumés IA) |
| `TELEGRAM_BOT_TOKEN` | Oui | Token de ton bot Telegram |
| `GK_TELEGRAM_CHAT_ID` | Oui | Chat où recevoir les alertes |

## Ce que tu peux surveiller

- Pages de prix concurrents
- Blogs / actualités
- APIs REST
- GitHub releases
- Pages d'accueil
- Flux RSS / Atom
- Pages d'emploi (détection levée de fonds)
- Pages de changelog
- Profils LinkedIn / Twitter

## Roadmap

- [x] Core engine (fetch, snapshot, detect)
- [x] DeepSeek summarizer (via env var)
- [x] Telegram alerts (via env var)
- [ ] Email alerts (SMTP)
- [ ] Dashboard web statique
- [ ] Export des changements (PDF/CSV)
- [ ] Multi-utilisateurs
- [ ] Bot Telegram interactif (@GKWatchBot)

---

**GKWatch** — Un projet GK365 · 19€ paiement unique
