#!/usr/bin/env python3
"""
GKWatch Core — Agent de veille universel
Scan → Snapshots → Détection → Résumé DeepSeek → Alerte

Usage:
  python3 gkwatch_core.py --check-all       # Vérifie toutes les cibles
  python3 gkwatch_core.py --check <target>   # Vérifie une cible spécifique
  python3 gkwatch_core.py --init             # Initialise les snapshots initiaux
  python3 gkwatch_core.py --list             # Liste les cibles configurées
  python3 gkwatch_core.py --dry-run          # Test sans envoyer d'alerte
"""

import json
import os
import sys
import subprocess
import urllib.request
import hashlib
from datetime import datetime, timezone
from pathlib import Path

# ─── Paths ────────────────────────────────────────────────────────────────
BASE = os.path.expanduser("~/gkwatch")
TARGETS_DIR = os.path.join(BASE, "targets")
SNAPSHOTS_DIR = os.path.join(BASE, "data", "snapshots")
LOGS_DIR = os.path.join(BASE, "data", "logs")
CONFIG_PATH = os.path.join(BASE, "gkwatch.json")
# API keys lues depuis les variables d'environnement (DEEPSEEK_API_KEY, TELEGRAM_BOT_TOKEN, GK_TELEGRAM_CHAT_ID)
# ou configurées dans gkwatch.json

# ─── Default config ───────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "name": "GKWatch",
    "version": "0.1.0",
    "created": datetime.now(timezone.utc).isoformat(),
    "alerts": {
        "telegram": {
            "enabled": True,
            "chat_id": ""
        },
        "email": {
            "enabled": False,
            "smtp": "",
            "to": ""
        }
    },
    "deepseek": {
        "model": "deepseek-chat",
        "temperature": 0.3,
        "summary_max_tokens": 500
    },
    "snapshot_retention_days": 30,
    "check_interval_default_mins": 1440
}


# ─── Helpers ──────────────────────────────────────────────────────────────

def ensure_dirs():
    for d in [SNAPSHOTS_DIR, LOGS_DIR]:
        os.makedirs(d, exist_ok=True)


def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] {msg}"
    print(line, file=sys.stderr)
    log_file = os.path.join(LOGS_DIR, f"gkwatch_{datetime.now().strftime('%Y%m')}.log")
    with open(log_file, "a") as f:
        f.write(line + "\n")


def load_config():
    """Load or create config."""
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        log(f"Config créée : {CONFIG_PATH}")
    with open(CONFIG_PATH) as f:
        return json.load(f)


def load_targets():
    """Load all target configs from targets/ directory."""
    targets = []
    if not os.path.isdir(TARGETS_DIR):
        log(f"Dossier targets introuvable : {TARGETS_DIR}", "ERROR")
        return targets
    for fname in os.listdir(TARGETS_DIR):
        if fname.endswith(".json"):
            try:
                with open(os.path.join(TARGETS_DIR, fname)) as f:
                    data = json.load(f)
                targets.extend(data.get("targets", []))
            except Exception as e:
                log(f"Erreur chargement {fname}: {e}", "WARN")
    return targets


def get_snapshot_path(target_id):
    """Path for the last snapshot of a target."""
    safe = target_id.replace("/", "_").replace(".", "_")
    return os.path.join(SNAPSHOTS_DIR, f"{safe}.json")


def load_snapshot(target_id):
    """Load the last known snapshot."""
    path = get_snapshot_path(target_id)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return None


def save_snapshot(target_id, data):
    """Save a new snapshot."""
    path = get_snapshot_path(target_id)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)


def snapshot_hash(data):
    """Hash of the raw data for change detection."""
    raw = json.dumps(data, sort_keys=True, default=str) if isinstance(data, (dict, list)) else str(data)
    return hashlib.sha256(raw.encode()).hexdigest()


# ─── Fetcher — récupère les données ──────────────────────────────────────

def fetch_target(target):
    """Fetch data from a target."""
    url = target.get("url")
    target_type = target.get("type", "raw")
    headers = {
        "User-Agent": "GKWatch/0.1 (veille-concurrentielle)"
    }

    # For GitHub API, add token if available for higher rate limits
    gh_token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if gh_token and "github.com" in url:
        headers["Authorization"] = f"Bearer {gh_token}"

    log(f"Fetching {target.get('id')} : {url}")

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode()
    except Exception as e:
        log(f"Erreur fetch {target.get('id')}: {e}", "ERROR")
        return None

    if target_type == "json":
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            log(f"Erreur parse JSON {target.get('id')}: {e}", "ERROR")
            return None

    return raw


# ─── Comparaison ──────────────────────────────────────────────────────────

def extract_selector(data, selector):
    """Simple JSON path extraction. Supports $.key.nested[].key"""
    import re
    if not selector or data is None:
        return data

    parts = selector.replace("$.", "").replace(".[", ".").split(".")
    current = data

    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list):
            # Try numeric index
            try:
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            except ValueError:
                # Skip - maybe array filter
                break
        else:
            return None
    return current


def detect_changes(target, old_data, new_data):
    """Compare old and new data, return differences."""
    if old_data is None:
        return {"status": "new", "detail": "Première surveillance — snapshot initial créé"}

    old_hash = snapshot_hash(old_data)
    new_hash = snapshot_hash(new_data)

    if old_hash == new_hash:
        return {"status": "unchanged", "detail": "Aucun changement détecté"}

    selector = target.get("selector", "")
    old_val = extract_selector(old_data, selector) if selector else old_data
    new_val = extract_selector(new_data, selector) if selector else new_data

    # For lists, show what changed
    if isinstance(old_val, list) and isinstance(new_val, list):
        old_set = set(json.dumps(i, sort_keys=True, default=str) for i in old_val)
        new_set = set(json.dumps(i, sort_keys=True, default=str) for i in new_val)
        added = list(new_set - old_set)
        removed = list(old_set - new_set)
        changes = []
        if added:
            changes.append(f"+{len(added)} nouveaux éléments")
        if removed:
            changes.append(f"-{len(removed)} éléments supprimés")
        return {
            "status": "changed",
            "detail": ", ".join(changes) if changes else "Contenu modifié",
            "added": [json.loads(a) for a in added[:5]],
            "removed": [json.loads(r) for r in removed[:5]]
        }

    return {"status": "changed", "detail": "Contenu modifié"}


# ─── Résumé DeepSeek ─────────────────────────────────────────────────────

def get_deepseek_key():
    """Get DeepSeek API key from environment variable."""
    return os.environ.get("DEEPSEEK_API_KEY") or None


def summarize_change(target, change_info, new_data):
    """Use DeepSeek to summarize what changed and why it matters."""
    if change_info["status"] == "unchanged":
        return None

    api_key = get_deepseek_key()
    if not api_key:
        return "Aucune clé DeepSeek — changement détecté mais non résumé"

    name = target.get("name", target.get("id", "?"))
    summary_prompt = target.get("summary_prompt", "Résume ce changement en français")

    # Build the prompt
    selector = target.get("selector", "")
    relevant_data = extract_selector(new_data, selector) if selector else new_data

    data_str = json.dumps(relevant_data, indent=2, ensure_ascii=False, default=str)[:3000]

    prompt = f"""Tu es GKWatch, un agent de veille automatique. Ton rôle est de résumer les changements détectés sur une source surveillée.

Surveillance : {name}
Changement : {change_info['detail']}

Données actuelles :
```json
{data_str}
```

{summary_prompt}

Format : 2-3 phrases max, factuel, sans bla-bla. Commence directement par le résumé."""

    try:
        req = urllib.request.Request(
            "https://api.deepseek.com/v1/chat/completions",
            data=json.dumps({
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": "Tu es un assistant concis qui résume des changements."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.3,
                "max_tokens": 500
            }).encode(),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            return result["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log(f"Erreur DeepSeek: {e}", "WARN")
        return f"Changement détecté sur {name} — résumé non disponible"


# ─── Alertes ──────────────────────────────────────────────────────────────

def send_telegram_alert(config, target, summary):
    """Send alert via Telegram bot."""
    # Priorité : env var > config file > échec
    chat_id = os.environ.get("GK_TELEGRAM_CHAT_ID") or config.get("alerts", {}).get("telegram", {}).get("chat_id", "")
    if not chat_id:
        log("Pas de chat_id Telegram configuré (GK_TELEGRAM_CHAT_ID ou config)", "WARN")
        return False

    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not bot_token:
        log("Bot token introuvable (TELEGRAM_BOT_TOKEN)", "ERROR")
        return False

    name = target.get("name", target.get("id", "?"))
    url = target.get("url", "")

    text = f"🔍 GKWatch — {name}\n{summary}\n\nSource : {url}"

    # Remove Markdown parse_mode to avoid 400 errors on special chars
    payload = json.dumps({
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": True
    }).encode()

    try:
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{bot_token}/sendMessage",
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=15)
        log(f"Alerte envoyée Telegram {chat_id}")
        return True
    except Exception as e:
        log(f"Erreur envoi Telegram: {e}", "ERROR")
        return False


def dispatch_alert(config, target, summary, dry_run=False):
    """Send alert to all configured channels."""
    if dry_run:
        print(f"\n🔍 GKWatch — {target.get('name', target.get('id', '?'))}")
        print(summary)
        print(f"Source : {target.get('url', '')}")
        return True

    if config.get("alerts", {}).get("telegram", {}).get("enabled", False):
        send_telegram_alert(config, target, summary)


# ─── Target Check ─────────────────────────────────────────────────────────

def check_target(target, dry_run=False, config=None):
    """Check one target, detect changes, alert."""
    if config is None:
        config = load_config()
    target_id = target.get("id", "unknown")
    log(f"Vérification de {target_id}...")

    # Fetch new data
    new_data = fetch_target(target)
    if new_data is None:
        log(f"Échec fetch {target_id}", "ERROR")
        return False

    # Load previous snapshot
    old_snapshot = load_snapshot(target_id)

    # Detect changes
    change = detect_changes(target, old_snapshot, new_data)

    if change["status"] == "unchanged":
        log(f"{target_id} : inchangé")
        # Update timestamp but keep data
        save_snapshot(target_id, new_data)
        return True

    if change["status"] == "new":
        log(f"{target_id} : premier snapshot")
        save_snapshot(target_id, new_data)
        return True

    # Change detected!
    log(f"{target_id} : CHANGEMENT DÉTECTÉ — {change['detail']}")

    # Summarize with DeepSeek
    summary = summarize_change(target, change, new_data)
    if summary:
        dispatch_alert(config, target, summary, dry_run=dry_run)

    # Save new snapshot
    save_snapshot(target_id, new_data)
    return True


# ─── CLI ──────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="GKWatch — Agent de veille universel")
    parser.add_argument("--check-all", action="store_true", help="Vérifie toutes les cibles")
    parser.add_argument("--check", type=str, help="Vérifie une cible spécifique (ID)")
    parser.add_argument("--init", action="store_true", help="Initialise TOUS les snapshots")
    parser.add_argument("--list", action="store_true", help="Liste les cibles configurées")
    parser.add_argument("--dry-run", action="store_true", help="Test sans envoi d'alerte")
    args = parser.parse_args()

    ensure_dirs()
    config = load_config()
    targets = load_targets()

    if args.list:
        print(f"GKWatch — {len(targets)} cibles configurées :")
        print("─" * 50)
        for t in targets:
            tags = ", ".join(t.get("tags", []))
            print(f"  {t.get('id', '?')}")
            print(f"    Nom : {t.get('name', '?')}")
            print(f"    URL : {t.get('url', '?')}")
            print(f"    Tags : {tags}")
            print()
        return

    if args.init:
        log(f"Initialisation de {len(targets)} cibles...")
        ok = 0
        for t in targets:
            data = fetch_target(t)
            if data:
                save_snapshot(t["id"], data)
                ok += 1
                log(f"  ✅ {t['id']}")
            else:
                log(f"  ❌ {t['id']} — échec")
        log(f"Initialisation terminée : {ok}/{len(targets)} cibles OK")
        return

    if args.check:
        matching = [t for t in targets if t.get("id") == args.check]
        if not matching:
            log(f"Cible '{args.check}' introuvable", "ERROR")
            sys.exit(1)
        check_target(matching[0], dry_run=args.dry_run)
        return

    if args.check_all:
        log(f"Vérification de {len(targets)} cibles...")
        results = {"ok": 0, "fail": 0, "changed": 0}
        for t in targets:
            ok = check_target(t, dry_run=args.dry_run, config=config)
            if ok:
                results["ok"] += 1
            else:
                results["fail"] += 1
        log(f"Terminé : {results['ok']} OK, {results['fail']} échecs")
        return

    parser.print_help()


if __name__ == "__main__":
    main()
