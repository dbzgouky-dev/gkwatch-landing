# 🔍 GKWatch — Agent de Veille Universel

Surveillance concurrentielle automatisée. Pas de veille manuelle.
Juste des alertes quand ça change.

**Self-hosted · Python pur · Alertes Telegram · Résumés IA · Prospection**

---

## Tarifs

| Tier | Prix | Cibles | IA | Prospection | Fréquence |
|------|------|--------|----|-------------|-----------|
| **Free** | 0 € | 3 | ❌ | ❌ | 24h |
| **Starter** | 19€/mois | 5 | ❌ | ❌ | 24h |
| **Pro** | 49€/mois | 25 | ✅ DeepSeek | ✅ | 1h |
| **Pack** | 199€ lifetime | Illimité | ✅ | ✅ | 15 min |

- **Starter →** https://buy.stripe.com/eVq7sNccldQuaZkcY02cg03
- **Pro →** https://buy.stripe.com/7sY9AV0tDcMq6J4gac2cg04
- **Pack →** https://buy.stripe.com/fZu5kFgsBfYC3wS9LO2cg05

---

## Architecture

```
gkwatch/
├── core/
│   ├── gkwatch_core.py    → Moteur principal
│   └── license.py         → Validation licence & tiers
├── gkwatch.json           → Configuration (alertes, stockage, tiers)
├── targets/               → Cibles à surveiller (JSON)
│   ├── default.json       → 3 cibles prêtes à l'emploi
│   └── ...                → Tes cibles personnalisées
├── data/
│   ├── snapshots/         → États précédents pour comparaison
│   ├── logs/              → Journal d'activité
│   └── licenses/          → Clés de licence (payantes)
└── site/
    └── landing.html       → Page d'accueil du projet
```

## Prérequis

- **Python 3.8+**
- **Un bot Telegram** (crée-le sur @BotFather)
- **Ton chat ID Telegram** (obtiens-le sur @userinfobot)
- **Optionnel : une clé API DeepSeek** (pour les résumés IA — Pro/Pack)
- **Optionnel : une licence GKWatch** (pour débloquer les tiers)

## Installation rapide

```bash
# 1. Décompresse le pack
unzip gkwatch-pack-v2.zip -d ~/gkwatch
cd ~/gkwatch

# 2. Configure tes clés API
nano .env

# 3. Source et init
set -a && source .env && set +a
python3 core/gkwatch_core.py --init

# 4. Teste
python3 core/gkwatch_core.py --check-all --dry-run

# 5. Vérifie ta licence
python3 core/gkwatch_core.py --license

# 6. Automatise (cron toutes les 30 min)
# crontab -e
# */30 * * * * cd ~/gkwatch && python3 core/gkwatch_core.py --check-all
```

## Utilisation

```bash
# Initialiser les snapshots
python3 core/gkwatch_core.py --init

# Vérifier toutes les cibles
python3 core/gkwatch_core.py --check-all

# Vérifier une cible spécifique
python3 core/gkwatch_core.py --check <target_id>

# Lister les cibles
python3 core/gkwatch_core.py --list

# Voir le statut licence
python3 core/gkwatch_core.py --license

# Test sans alerte
python3 core/gkwatch_core.py --check-all --dry-run
```

## Configuration d'une cible

Ajoute un fichier JSON dans `targets/` :

```json
{
  "targets": [
    {
      "id": "mon-concurrent",
      "name": "Site concurrent",
      "url": "https://concurrent.com/pricing",
      "type": "raw",
      "interval_mins": 1440,
      "summary_prompt": "Résume les changements de prix"
    }
  ]
}
```

- `type` : `"raw"` (HTML), `"json"` (API JSON)
- `selector` : extraction JSON (ex: `$.data.prices`)
- `interval_mins` : fréquence de vérification (défaut: 1440 = 24h)
- `summary_prompt` : instruction pour le résumé DeepSeek

## Variables d'environnement

| Variable | Obligatoire | Description |
|----------|-------------|-------------|
| `DEEPSEEK_API_KEY` | Non | Clé API DeepSeek (résumés IA) |
| `TELEGRAM_BOT_TOKEN` | Oui | Token de ton bot Telegram |
| `GK_TELEGRAM_CHAT_ID` | Oui | Chat où recevoir les alertes |
| `GK_LICENSE_KEY` | Non | Clé de licence (Starter/Pro/Pack) |

## Tiers & Limites

Le moteur vérifie automatiquement ta licence au lancement :

- **Free** : 3 cibles max, check 24h, pas d'IA, pas de prospection
- **Starter** : 5 cibles max, check 24h, pas d'IA
- **Pro** : 25 cibles max, check 1h, IA DeepSeek, prospection automatique
- **Pack** : Illimité, check 15 min, IA + prospection, lifetime

Les cibles de prospection (Show HN, ProductHunt, GitHub Trending) sont
ignorées sur les tiers Free/Starter.

## Ce que tu peux surveiller

- Pages de prix concurrents
- Blogs / actualités
- APIs REST
- GitHub releases
- Pages d'accueil
- Flux RSS / Atom
- Pages d'emploi (détection levée de fonds)
- Pages de changelog
- Profils LinkedIn / Twitter

## Roadmap

- [x] Core engine v2 (fetch, snapshot, detect, license)
- [x] DeepSeek summarizer (via env var)
- [x] Telegram alerts (via env var)
- [x] Licence system (Starter/Pro/Pack)
- [x] Tiers enforcement (targets, AI, prospection)
- [ ] Email alerts (SMTP)
- [ ] Dashboard web statique
- [ ] Export des changements (PDF/CSV)
- [ ] Bot Telegram interactif (@GKWatchBot)

---

**GKWatch** — Un projet [GK365](https://gk365.fr)
