#!/usr/bin/env bash
# GKWatch — Installation automatique (v2)
set -euo pipefail

INSTALL_DIR="${HOME}/gkwatch"
LICENSE_DIR="${INSTALL_DIR}/data/licenses"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  GKWatch v2 — Installation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Vérifier Python
if ! command -v python3 &>/dev/null; then
    echo "❌ Python3 requis. Installe-le d'abord."
    echo "  Ubuntu/Debian : sudo apt install python3"
    echo "  MacOS : brew install python3"
    exit 1
fi

echo "✅ Python3 $(python3 --version)"

# Créer dossier
mkdir -p "$INSTALL_DIR/core" "$INSTALL_DIR/data/snapshots" "$INSTALL_DIR/data/logs" "$INSTALL_DIR/data/licenses" "$INSTALL_DIR/targets"
cd "$INSTALL_DIR"

# Vérifier si le pack est déjà présent
if [ ! -f "core/gkwatch_core.py" ]; then
    echo "📦 Téléchargement de GKWatch..."
    echo ""
    echo "  Tu peux télécharger la version gratuite depuis GitHub :"
    echo "  → https://github.com/dbzgouky-dev/gkwatch-core"
    echo ""
    echo "  Ou acheter une licence payante (Starter/Pro/Pack) :"
    echo "  → https://gkwatch.gk365.fr"
    echo ""
    echo "  Une fois téléchargé, décompresse-le ici : $INSTALL_DIR"
    echo "  Puis relance ce script."
    exit 0
fi

echo "✅ GKWatch détecté dans $INSTALL_DIR"

# ─── Configuration ────────────────────────────────────────────────────
ENV_FILE="$INSTALL_DIR/.env"

if [ ! -f "$ENV_FILE" ]; then
    echo ""
    echo "🔧 Configuration des clés API"
    echo "  (Tu peux aussi créer .env manuellement)"
    echo ""

    read -rp "🧠 Clé API DeepSeek (optionnelle, laisser vide pour ignorer) : " DEEPSEEK_KEY
    read -rp "🤖 Token de ton bot Telegram (obtiens-le sur @BotFather) : " BOT_TOKEN
    read -rp "👤 Ton chat ID Telegram (obtiens-le sur @userinfobot) : " CHAT_ID
    read -rp "🔑 Licence key GKWatch (optionnelle, laisser vide pour mode Free) : " LICENSE_KEY

    cat > "$ENV_FILE" << EOF
# GKWatch v2 — Configuration API
# Copie tes clés ici. Ce fichier est lu automatiquement.

# Optionnel — nécessaire pour les résumés IA des changements
# DEEPSEEK_API_KEY=sk-...

# Obligatoire — ton bot Telegram
TELEGRAM_BOT_TOKEN=${BOT_TOKEN}

# Obligatoire — chat où recevoir les alertes
GK_TELEGRAM_CHAT_ID=${CHAT_ID}

# Optionnel — clé de licence pour débloquer les fonctionnalités payantes
GK_LICENSE_KEY=${LICENSE_KEY}
EOF

    # If license key was provided, save it
    if [ -n "$LICENSE_KEY" ]; then
        echo "{\"key\": \"$LICENSE_KEY\", \"active\": true, \"tier\": \"starter\", \"type\": \"subscription\"}" > "$LICENSE_DIR/${LICENSE_KEY}.json"
    fi

    echo "✅ Fichier .env créé"
else
    echo "✅ Fichier .env existant"
fi

# ─── Premier lancement ────────────────────────────────────────────────
echo ""
echo "🚀 Vérification de la licence..."
python3 core/gkwatch_core.py --license 2>&1 || true

echo ""
echo "🚀 Initialisation des snapshots (première capture)..."
set -a
source .env
set +a
python3 core/gkwatch_core.py --init 2>&1 || echo "⚠️  Échec init — vérifie tes cibles dans targets/"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅ GKWatch v2 installé !"
echo ""
echo "  Prochaines étapes :"
echo "  1. Édite targets/default.json avec TES URLs à surveiller"
echo "  2. Relance : cd $INSTALL_DIR && python3 core/gkwatch_core.py --check-all"
echo "  3. Ajoute un cron pour l'automatisation :"
echo "     crontab -e"
echo "     */30 * * * * cd $INSTALL_DIR && python3 core/gkwatch_core.py --check-all"
echo ""
echo "  📖 Documentation : README.md"
echo "  🔗 Site : https://gkwatch.gk365.fr"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
