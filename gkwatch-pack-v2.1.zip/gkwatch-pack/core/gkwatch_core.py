#!/usr/bin/env python3
"""
GKWatch Core — Agent de veille universel
Scan → Snapshots → Détection → Résumé DeepSeek → Alerte

Usage:
  python3 gkwatch_core.py --check-all       # Vérifie toutes les cibles
  python3 gkwatch_core.py --check <target>   # Vérifie une cible spécifique
  python3 gkwatch_core.py --init             # Initialise les snapshots initiaux
  python3 gkwatch_core.py --list             # Liste les cibles configurées
  python3 gkwatch_core.py --license          # Affiche le statut licence
  python3 gkwatch_core.py --dry-run          # Test sans envoyer d'alerte
"""

import json
import os
import sys
import subprocess
import urllib.request
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from license import check_license, log_license_info, enforce_targets
import hashlib
from datetime import datetime, timezone
from pathlib import Path

# ─── Paths ────────────────────────────────────────────────────────────────
BASE = os.path.expanduser("~/gkwatch")
TARGETS_DIR = os.path.join(BASE, "targets")
SNAPSHOTS_DIR = os.path.join(BASE, "data", "snapshots")
LOGS_DIR = os.path.join(BASE, "data", "logs")
CONFIG_PATH = os.path.join(BASE, "gkwatch.json")
# API keys lues depuis les variables d'environnement (DEEPSEEK_API_KEY, TELEGRAM_BOT_TOKEN, GK_TELEGRAM_CHAT_ID)
# ou configurées dans gkwatch.json

# ─── Default config ───────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "name": "GKWatch",
    "version": "0.1.0",
    "created": datetime.now(timezone.utc).isoformat(),
    "alerts": {
        "telegram": {
            "enabled": True,
            "chat_id": ""
        },
        "email": {
            "enabled": False,
            "smtp": "",
            "to": ""
        }
    },
    "deepseek": {
        "model": "deepseek-chat",
        "temperature": 0.3,
        "summary_max_tokens": 500
    },
    "snapshot_retention_days": 30,
    "check_interval_default_mins": 1440
}


# ─── Helpers ──────────────────────────────────────────────────────────────

def ensure_dirs():
    for d in [SNAPSHOTS_DIR, LOGS_DIR]:
        os.makedirs(d, exist_ok=True)


def log(msg, level="INFO"):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] [{level}] {msg}"
    print(line, file=sys.stderr)
    log_file = os.path.join(LOGS_DIR, f"gkwatch_{datetime.now().strftime('%Y%m')}.log")
    with open(log_file, "a") as f:
        f.write(line + "\n")


def load_config():
    """Load or create config."""
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        log(f"Config créée : {CONFIG_PATH}")
    with open(CONFIG_PATH) as f:
        return json.load(f)


def load_targets(license_info=None):
    """Load all target configs from targets/ directory, enforcing tier limit."""
    if license_info is None:
        from license import check_license
        license_info = check_license()
    max_targets = license_info.get("max_targets", 3)
    targets = []
    if not os.path.isdir(TARGETS_DIR):
        log(f"Dossier targets introuvable : {TARGETS_DIR}", "ERROR")
        return targets
    
    count = 0
    for fname in sorted(os.listdir(TARGETS_DIR)):
        if not fname.endswith(".json"):
            continue
        try:
            with open(os.path.join(TARGETS_DIR, fname)) as f:
                data = json.load(f)
            file_targets = data.get("targets", [])
            for t in file_targets:
                if count >= max_targets:
                    log(f"Limite de {max_targets} cibles atteinte (tier: {license_info.get('tier','free')})", "WARN")
                    return targets
                targets.append(t)
                count += 1
        except Exception as e:
            log(f"Erreur chargement {fname}: {e}", "WARN")
    log(f"{len(targets)}/{max_targets} cibles chargées (tier: {license_info.get('tier','free')})")
    return targets


def get_snapshot_path(target_id):
    """Path for the last snapshot of a target."""
    safe = target_id.replace("/", "_").replace(".", "_")
    return os.path.join(SNAPSHOTS_DIR, f"{safe}.json")


def load_snapshot(target_id):
    """Load the last known snapshot."""
    path = get_snapshot_path(target_id)
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return None


def save_snapshot(target_id, data):
    """Save a new snapshot."""
    path = get_snapshot_path(target_id)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)


def snapshot_hash(data):
    """Hash of the raw data for change detection."""
    raw = json.dumps(data, sort_keys=True, default=str) if isinstance(data, (dict, list)) else str(data)
    return hashlib.sha256(raw.encode()).hexdigest()


# ─── Fetcher — récupère les données ──────────────────────────────────────

def fetch_target(target):
    """Fetch data from a target.
    
    Supports:
      - HTTP(S) raw fetch (type: raw | json)
      - JS-rendered fetch (js_render: true) via Playwright
    """
    url = target.get("url")
    target_type = target.get("type", "raw")
    js_render = target.get("js_render", False)

    log(f"Fetching {target.get('id')} : {url} (js_render={js_render})")

    # ─── JS Rendering via Playwright ──────────────────────────────
    if js_render:
        try:
            script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "js_render.js")
            node_path = os.environ.get("NODE_PATH", "")
            if not node_path:
                # Auto-detect global npm root
                result = subprocess.run(
                    ["npm", "root", "-g"],
                    capture_output=True, text=True, timeout=10
                )
                if result.returncode == 0:
                    node_path = result.stdout.strip()
            env = os.environ.copy()
            env["NODE_PATH"] = node_path
            result = subprocess.run(
                ["node", script_path, url, "30000"],
                capture_output=True, text=True, timeout=60,
                env=env
            )
            if result.returncode != 0:
                log(f"Erreur JS render {target.get('id')}: {result.stderr.strip()}", "ERROR")
                return None
            raw = result.stdout
        except subprocess.TimeoutExpired:
            log(f"Timeout JS render {target.get('id')}", "ERROR")
            return None
        except Exception as e:
            log(f"Erreur JS render {target.get('id')}: {e}", "ERROR")
            return None
        # Parse JSON response if needed
        if target_type == "json":
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                log(f"Erreur parse JSON (JS render) {target.get('id')}", "ERROR")
                return None
        return raw

    # ─── HTTP(S) Standard fetch ───────────────────────────────────
    headers = {
        "User-Agent": "GKWatch/0.1 (veille-concurrentielle)"
    }

    # For GitHub API, add token if available for higher rate limits
    gh_token = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if gh_token and "github.com" in url:
        headers["Authorization"] = f"Bearer {gh_token}"

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read().decode()
    except Exception as e:
        log(f"Erreur fetch {target.get('id')}: {e}", "ERROR")
        return None

    if target_type == "json":
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            log(f"Erreur parse JSON {target.get('id')}: {e}", "ERROR")
            return None

    return raw


# ─── Comparaison ──────────────────────────────────────────────────────────

def extract_selector(data, selector):
    """Simple JSON path extraction. Supports $.key.nested[].key"""
    import re
    if not selector or data is None:
        return data

    parts = selector.replace("$.", "").replace(".[", ".").split(".")
    current = data

    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list):
            # Try numeric index
            try:
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            except ValueError:
                # Skip - maybe array filter
                break
        else:
            return None
    return current


def detect_changes(target, old_data, new_data):
    """Compare old and new data, return differences."""
    if old_data is None:
        return {"status": "new", "detail": "Première surveillance — snapshot initial créé"}

    old_hash = snapshot_hash(old_data)
    new_hash = snapshot_hash(new_data)

    if old_hash == new_hash:
        return {"status": "unchanged", "detail": "Aucun changement détecté"}

    selector = target.get("selector", "")
    old_val = extract_selector(old_data, selector) if selector else old_data
    new_val = extract_selector(new_data, selector) if selector else new_data

    # For lists, show what changed
    if isinstance(old_val, list) and isinstance(new_val, list):
        old_set = set(json.dumps(i, sort_keys=True, default=str) for i in old_val)
        new_set = set(json.dumps(i, sort_keys=True, default=str) for i in new_val)
        added = list(new_set - old_set)
        removed = list(old_set - new_set)
        changes = []
        if added:
            changes.append(f"+{len(added)} nouveaux éléments")
        if removed:
            changes.append(f"-{len(removed)} éléments supprimés")
        return {
            "status": "changed",
            "detail": ", ".join(changes) if changes else "Contenu modifié",
            "added": [json.loads(a) for a in added[:5]],
            "removed": [json.loads(r) for r in removed[:5]]
        }

    return {"status": "changed", "detail": "Contenu modifié"}


# ─── Résumé DeepSeek ─────────────────────────────────────────────────────

def get_deepseek_key():
    """Get DeepSeek API key from environment variable."""
    return os.environ.get("DEEPSEEK_API_KEY") or None


def summarize_change(target, change_info, new_data):
    """Use DeepSeek to summarize what changed and why it matters."""
    if change_info["status"] == "unchanged":
        return None

    api_key = get_deepseek_key()
    if not api_key:
        return "Aucune clé DeepSeek — changement détecté mais non résumé"

    name = target.get("name", target.get("id", "?"))
    summary_prompt = target.get("summary_prompt", "Résume ce changement en français")

    # Build the prompt
    selector = target.get("selector", "")
    relevant_data = extract_selector(new_data, selector) if selector else new_data

    data_str = json.dumps(relevant_data, indent=2, ensure_ascii=False, default=str)[:3000]

    prompt = f"""Tu es GKWatch, un agent de veille automatique. Ton rôle est de résumer les changements détectés sur une source surveillée.

Surveillance : {name}
Changement : {change_info['detail']}

Données actuelles :
```json
{data_str}
```

{summary_prompt}

Format : 2-3 phrases max, factuel, sans bla-bla. Commence directement par le résumé."""

    try:
        req = urllib.request.Request(
            "https://api.deepseek.com/v1/chat/completions",
            data=json.dumps({
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": "Tu es un assistant concis qui résume des changements."},
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.3,
                "max_tokens": 500
            }).encode(),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            return result["choices"][0]["message"]["content"].strip()
    except Exception as e:
        log(f"Erreur DeepSeek: {e}", "WARN")
        return f"Changement détecté sur {name} — résumé non disponible"


# ─── Alertes ──────────────────────────────────────────────────────────────

def send_email_alert(config, target, summary):
    """Send alert via SMTP email."""
    smtp_config = config.get("alerts", {}).get("email", {})
    if not smtp_config.get("enabled", False):
        return False

    smtp_host = smtp_config.get("smtp_host", "")
    smtp_port = smtp_config.get("smtp_port", 587)
    smtp_user = smtp_config.get("smtp_user", "")
    smtp_pass = smtp_config.get("smtp_pass", "")
    to_addr = smtp_config.get("to", "")
    from_addr = smtp_config.get("from", smtp_user)

    if not all([smtp_host, smtp_user, smtp_pass, to_addr]):
        return False

    name = target.get("name", target.get("id", "?"))
    url = target.get("url", "")
    subject = f"[GKWatch] {name} — Changement détecté"
    body = f"""GKWatch — Alerte de changement

Cible : {name}
URL : {url}

{summary}

---
GKWatch — Veille concurrentielle automatisée
"""

    import smtplib
    from email.mime.text import MIMEText

    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["Subject"] = subject
        msg["From"] = from_addr
        msg["To"] = to_addr

        with smtplib.SMTP(smtp_host, smtp_port, timeout=15) as server:
            server.starttls()
            server.login(smtp_user, smtp_pass)
            server.send_message(msg)

        log(f"Alerte envoyée email {to_addr}")
        return True
    except Exception as e:
        log(f"Erreur envoi email: {e}", "ERROR")
        return False


def send_slack_alert(config, target, summary):
    """Send alert via Slack webhook.
    
    Configuration (priority: env var > config file):
      - Env: SLACK_WEBHOOK_URL
      - Config: alerts.slack.webhook_url
    """
    webhook_url = os.environ.get("SLACK_WEBHOOK_URL") or config.get("alerts", {}).get("slack", {}).get("webhook_url", "")
    if not webhook_url:
        return False

    name = target.get("name", target.get("id", "?"))
    url = target.get("url", "")

    payload = json.dumps({
        "text": f"🔍 GKWatch — {name}",
        "blocks": [
            {
                "type": "header",
                "text": {"type": "plain_text", "text": f"🔍 GKWatch — {name}"}
            },
            {
                "type": "section",
                "text": {"type": "mrkdwn", "text": summary}
            },
            {
                "type": "context",
                "elements": [
                    {"type": "mrkdwn", "text": f"<{url}|Voir la source> · GKWatch"}
                ]
            }
        ]
    }).encode()

    try:
        req = urllib.request.Request(
            webhook_url,
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=15)
        log(f"Alerte envoyée Slack")
        return True
    except Exception as e:
        log(f"Erreur envoi Slack: {e}", "ERROR")
        return False


def send_webhook_alert(config, target, summary):
    """Send alert via generic webhook (JSON POST).
    
    Configuration (priority: env var > config file):
      - Env: WEBHOOK_URL
      - Config: alerts.webhook.url
    """
    webhook_url = os.environ.get("WEBHOOK_URL") or config.get("alerts", {}).get("webhook", {}).get("url", "")
    if not webhook_url:
        return False

    payload = json.dumps({
        "source": "gkwatch",
        "event": "change_detected",
        "target": {
            "id": target.get("id"),
            "name": target.get("name"),
            "url": target.get("url")
        },
        "summary": summary,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }).encode()

    try:
        req = urllib.request.Request(
            webhook_url,
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=15)
        log(f"Alerte envoyée webhook {webhook_url}")
        return True
    except Exception as e:
        log(f"Erreur envoi webhook: {e}", "ERROR")
        return False


def send_telegram_alert(config, target, summary):
    """Send alert via Telegram bot."""
    # Priorité : env var > config file > échec
    chat_id = os.environ.get("GK_TELEGRAM_CHAT_ID") or config.get("alerts", {}).get("telegram", {}).get("chat_id", "")
    if not chat_id:
        log("Pas de chat_id Telegram configuré (GK_TELEGRAM_CHAT_ID ou config)", "WARN")
        return False

    bot_token = os.environ.get("TELEGRAM_BOT_TOKEN")
    if not bot_token:
        log("Bot token introuvable (TELEGRAM_BOT_TOKEN)", "ERROR")
        return False

    name = target.get("name", target.get("id", "?"))
    url = target.get("url", "")

    text = f"🔍 GKWatch — {name}\n{summary}\n\nSource : {url}"

    # Remove Markdown parse_mode to avoid 400 errors on special chars
    payload = json.dumps({
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": True
    }).encode()

    try:
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{bot_token}/sendMessage",
            data=payload,
            headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=15)
        log(f"Alerte envoyée Telegram {chat_id}")
        return True
    except Exception as e:
        log(f"Erreur envoi Telegram: {e}", "ERROR")
        return False


def dispatch_alert(config, target, summary, dry_run=False):
    """Send alert to all configured channels."""
    if dry_run:
        print(f"\n🔍 GKWatch — {target.get('name', target.get('id', '?'))}")
        print(summary)
        print(f"Source : {target.get('url', '')}")
        return True

    results = []

    # Telegram
    if config.get("alerts", {}).get("telegram", {}).get("enabled", False):
        results.append(("telegram", send_telegram_alert(config, target, summary)))

    # Email
    if config.get("alerts", {}).get("email", {}).get("enabled", False):
        results.append(("email", send_email_alert(config, target, summary)))

    # Slack
    if config.get("alerts", {}).get("slack", {}).get("enabled", False):
        results.append(("slack", send_slack_alert(config, target, summary)))

    # Generic webhook
    if config.get("alerts", {}).get("webhook", {}).get("enabled", False):
        results.append(("webhook", send_webhook_alert(config, target, summary)))

    sent = [c for c, ok in results if ok]
    failed = [c for c, ok in results if not ok]
    if sent:
        log(f"Alertes envoyées: {', '.join(sent)}")
    if failed:
        log(f"Alertes échouées: {', '.join(failed)}", "WARN")


# ─── Target Check ─────────────────────────────────────────────────────────

def check_target(target, dry_run=False, config=None, license_info=None):
    """Check one target, detect changes, alert."""
    if config is None:
        config = load_config()
    if license_info is None:
        from license import check_license
        license_info = check_license()

    target_id = target.get("id", "unknown")
    target_tags = target.get("tags", [])

    # Tier enforcement: skip prospection targets on free/starter
    is_prospection = "prospection" in target_tags
    if is_prospection and not license_info.get("prospection", False):
        log(f"{target_id} : ignoré (prospection non disponible en tier {license_info.get('tier','free')})", "INFO")
        return True

    log(f"Vérification de {target_id}...")

    # Fetch new data
    new_data = fetch_target(target)
    if new_data is None:
        log(f"Échec fetch {target_id}", "ERROR")
        return False

    # Load previous snapshot
    old_snapshot = load_snapshot(target_id)

    # Detect changes
    change = detect_changes(target, old_snapshot, new_data)

    if change["status"] == "unchanged":
        log(f"{target_id} : inchangé")
        # Update timestamp but keep data
        save_snapshot(target_id, new_data)
        return True

    if change["status"] == "new":
        log(f"{target_id} : premier snapshot")
        save_snapshot(target_id, new_data)
        return True

    # Change detected!
    log(f"{target_id} : CHANGEMENT DÉTECTÉ — {change['detail']}")

    # Summarize with DeepSeek (tier enforcement)
    has_ai = license_info.get("ai_summary", False)
    if has_ai:
        summary = summarize_change(target, change, new_data)
    else:
        # Basic summary without AI
        summary = f"Changement détecté sur {target.get('name', target_id)} — {change['detail']}"
        if 'added' in change:
            added = change.get('added', [])
            for item in added[:3]:
                if isinstance(item, dict):
                    name = item.get('name', item.get('title', item.get('login', '?')))
                    url = item.get('url', item.get('html_url', ''))
                    summary += f"\n  + {name} ({url})" if url else f"\n  + {name}"

    if summary:
        dispatch_alert(config, target, summary, dry_run=dry_run)

    # Save new snapshot
    save_snapshot(target_id, new_data)
    return True


# ─── CLI ──────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser(description="GKWatch — Agent de veille universel")
    parser.add_argument("--check-all", action="store_true", help="Vérifie toutes les cibles")
    parser.add_argument("--check", type=str, help="Vérifie une cible spécifique (ID)")
    parser.add_argument("--init", action="store_true", help="Initialise TOUS les snapshots")
    parser.add_argument("--list", action="store_true", help="Liste les cibles configurées")
    parser.add_argument("--dry-run", action="store_true", help="Test sans envoi d'alerte")
    parser.add_argument("--license", action="store_true", help="Affiche le statut de la licence")
    args = parser.parse_args()

    ensure_dirs()
    config = load_config()
    targets = load_targets()

    # Load license info for tier enforcement
    LICENSE = check_license()
    log_license_info(LICENSE)

    if args.list:
        print(f"GKWatch — {len(targets)} cibles configurées :")
        print("─" * 50)
        for t in targets:
            tags = ", ".join(t.get("tags", []))
            print(f"  {t.get('id', '?')}")
            print(f"    Nom : {t.get('name', '?')}")
            print(f"    URL : {t.get('url', '?')}")
            print(f"    Tags : {tags}")
            print()
        return

    if args.init:
        log(f"Initialisation de {len(targets)} cibles...")
        ok = 0
        for t in targets:
            data = fetch_target(t)
            if data:
                save_snapshot(t["id"], data)
                ok += 1
                log(f"  ✅ {t['id']}")
            else:
                log(f"  ❌ {t['id']} — échec")
        log(f"Initialisation terminée : {ok}/{len(targets)} cibles OK")
        return

    if args.check:
        matching = [t for t in targets if t.get("id") == args.check]
        if not matching:
            log(f"Cible '{args.check}' introuvable", "ERROR")
            sys.exit(1)
        check_target(matching[0], dry_run=args.dry_run, license_info=LICENSE)
        return

    # ─── License check ───────────────────────────────────────
    if args.license:
        lic = check_license()
        log_license_info(lic)
        sys.exit(0)

    if args.check_all:
        log(f"Vérification de {len(targets)} cibles...")
        results = {"ok": 0, "fail": 0, "changed": 0}
        for t in targets:
            ok = check_target(t, dry_run=args.dry_run, config=config, license_info=LICENSE)
            if ok:
                results["ok"] += 1
            else:
                results["fail"] += 1
        log(f"Terminé : {results['ok']} OK, {results['fail']} échecs")

        # Generate dashboard after checks
        if not args.dry_run:
            try:
                dash_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard_generator.py")
                subprocess.run([sys.executable, dash_path, "--update"], capture_output=True, text=True, timeout=30)
            except Exception as e:
                log(f"Dashboard: {e}", "WARN")
        return

    parser.print_help()


if __name__ == "__main__":
    main()
