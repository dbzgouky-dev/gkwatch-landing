#!/usr/bin/env python3
"""
GKWatch License — Validation et enforcement des tiers.

Les clés de licence sont générées par le webhook Stripe et stockées
dans data/licenses/. Le core engine vérifie la licence avant d'exécuter
les fonctionnalités réservées à certains tiers.

Usage:
    from license import check_license, get_license_info
    lic = get_license_info()
    if lic and lic["tier"] in ("pro", "pack"):
        run_prospection()
"""

import json, os, sys, time, uuid
from pathlib import Path
from datetime import datetime, timezone

BASE_DIR = os.path.expanduser("~/gkwatch")
LICENSES_DIR = os.path.join(BASE_DIR, "data", "licenses")
CONFIG_PATH = os.path.join(BASE_DIR, "gkwatch.json")

# ─── Default tiers (no license = Starter-limited) ─────────────────────
# Ces limites sont appliquées si aucune licence valide n'est trouvée.
FREE_TIER = {
    "tier": "free",
    "name": "GKWatch Free",
    "max_targets": 3,
    "ai_summary": False,
    "prospection": False,
    "check_interval_mins": 1440,  # 24h
    "history_days": 7
}

TIER_LIMITS = {
    "free": {
        "max_targets": 3,
        "ai_summary": False,
        "prospection": False,
        "check_interval_mins": 1440,
        "history_days": 7
    },
    "starter": {
        "max_targets": 5,
        "ai_summary": False,
        "prospection": False,
        "check_interval_mins": 1440,
        "history_days": 30
    },
    "pro": {
        "max_targets": 25,
        "ai_summary": True,
        "prospection": True,
        "check_interval_mins": 60,   # 1h
        "history_days": 90
    },
    "pack": {
        "max_targets": 999,
        "ai_summary": True,
        "prospection": True,
        "check_interval_mins": 15,   # 15 min
        "history_days": 365
    }
}


def load_licenses():
    """Load all license files from disk."""
    lic_dir = Path(LICENSES_DIR)
    if not lic_dir.exists():
        return []
    licenses = []
    for f in lic_dir.glob("GK-*.json"):
        try:
            with open(f) as fh:
                lic = json.load(fh)
            if lic.get("active", False):
                licenses.append(lic)
        except (json.JSONDecodeError, IOError):
            continue
    return licenses


def get_first_valid_license():
    """Return the first valid (active, not expired) license found."""
    for lic in load_licenses():
        # Check expiry for subscriptions (no expiry for lifetime)
        if lic.get("type") == "subscription" and lic.get("stripe_subscription_id"):
            # License stays valid until webhook marks it inactive
            pass
        return lic
    return None


def check_license():
    """Check if a valid license exists and return its tier info."""
    lic = get_first_valid_license()
    if not lic:
        return FREE_TIER

    tier = lic.get("tier", "free")
    limits = TIER_LIMITS.get(tier, TIER_LIMITS["free"])
    return {
        "tier": tier,
        "name": lic.get("name", f"GKWatch {tier.title()}"),
        "max_targets": limits["max_targets"],
        "ai_summary": limits["ai_summary"],
        "prospection": limits["prospection"],
        "check_interval_mins": limits["check_interval_mins"],
        "history_days": limits["history_days"],
        "license_key": lic.get("key", ""),
        "type": lic.get("type", "free")
    }


def get_tier_limit(tier_info, key, default=None):
    """Get a specific limit from tier info."""
    if not tier_info:
        return default
    return tier_info.get(key, default)


def enforce_targets(targets, tier_info):
    """Filter targets based on tier limit."""
    max_targets = get_tier_limit(tier_info, "max_targets", 3)
    if len(targets) <= max_targets:
        return targets
    print(f"[LICENSE] Limité à {max_targets} cibles (tier: {tier_info.get('tier', 'free')}), "
          f"{len(targets)} configurées.")
    return targets[:max_targets]


def log_license_info(tier_info):
    """Print license status."""
    tier = tier_info.get("tier", "free")
    name = tier_info.get("name", "GKWatch Free")
    key = tier_info.get("license_key", "")
    lic_type = tier_info.get("type", "free")
    print(f"[LICENSE] Tier: {name} ({lic_type})")
    if key:
        print(f"[LICENSE] Clé: {key}")
    print(f"[LICENSE] Cibles max: {tier_info.get('max_targets', 3)}")
    print(f"[LICENSE] IA: {'✅' if tier_info.get('ai_summary', False) else '❌'}")
    print(f"[LICENSE] Prospection: {'✅' if tier_info.get('prospection', False) else '❌'}")


# ─── CLI test ────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=== GKWatch License Check ===")
    lic = check_license()
    log_license_info(lic)
    print(json.dumps(lic, indent=2))
