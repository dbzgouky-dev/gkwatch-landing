#!/usr/bin/env node
/**
 * GKWatch — JS Renderer
 * Utilise Playwright pour charger des pages JS (React, Vue, SPA)
 * et retourne le contenu HTML final après exécution du JavaScript.
 *
 * Usage:  NODE_PATH=$(npm root -g) node js_render.js <url> [timeout_ms]
 * Output: Le HTML complet de la page (stdout)
 *
 * Retourne code 1 + message d'erreur sur stderr si échec.
 */

const { chromium } = require('playwright');

(async () => {
  const url = process.argv[2];
  const timeout = parseInt(process.argv[3] || '15000', 10);

  if (!url) {
    console.error('Usage: js_render.js <url> [timeout_ms]');
    process.exit(1);
  }

  let browser;
  try {
    browser = await chromium.launch({
      headless: true,
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--disable-accelerated-2d-canvas',
        '--single-process'
      ]
    });

    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
      viewport: { width: 1920, height: 1080 },
      locale: 'fr-FR',
      timezoneId: 'Europe/Paris'
    });

    const page = await context.newPage();

    // Intercepter les requêtes pour bloquer les ressources non essentielles
    await page.route('**/*.{png,jpg,jpeg,gif,svg,ico,woff,woff2,ttf,eot,mp4,webm,mp3}', route => route.abort());
    await page.route('**/analytics.js**', route => route.abort());
    await page.route('**/gtag/**', route => route.abort());

    await page.goto(url, {
      waitUntil: 'networkidle',
      timeout: timeout
    });

    // Attendre un peu que le JS asynchrone se termine
    await page.waitForTimeout(2000);

    const content = await page.content();
    console.log(content);

  } catch (err) {
    console.error(`[JS_RENDER_ERROR] ${url}: ${err.message}`, err);
    process.exit(1);
  } finally {
    if (browser) await browser.close();
  }
})();
