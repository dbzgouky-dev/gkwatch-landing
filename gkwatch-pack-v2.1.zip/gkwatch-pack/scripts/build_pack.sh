#!/usr/bin/env bash
# GKWatch — Build le pack v2 (distribution zip)
set -euo pipefail

PACK_DIR="/tmp/gkwatch-pack-build"
VERSION="${1:-v2}"
OUTPUT="${HOME}/gkwatch/gkwatch-pack-${VERSION}.zip"

echo "=== GKWatch Pack Build ${VERSION} ==="
rm -rf "$PACK_DIR"
mkdir -p "$PACK_DIR/gkwatch-pack/core" "$PACK_DIR/gkwatch-pack/targets" "$PACK_DIR/gkwatch-pack/templates" "$PACK_DIR/gkwatch-pack/scripts" "$PACK_DIR/gkwatch-pack/data/snapshots" "$PACK_DIR/gkwatch-pack/data/logs" "$PACK_DIR/gkwatch-pack/data/licenses"

# ─── Files ──────────────────────────────────────────────────
cp "${HOME}/gkwatch/core/gkwatch_core.py" "$PACK_DIR/gkwatch-pack/core/"
cp "${HOME}/gkwatch/core/license.py" "$PACK_DIR/gkwatch-pack/core/"
cp "${HOME}/gkwatch/core/js_render.js" "$PACK_DIR/gkwatch-pack/core/"
cp "${HOME}/gkwatch/targets/default.json" "$PACK_DIR/gkwatch-pack/targets/"
cp "${HOME}/gkwatch/templates/install.sh" "$PACK_DIR/gkwatch-pack/"
cp "${HOME}/gkwatch/templates/exemples_business.json" "$PACK_DIR/gkwatch-pack/templates/"
cp "${HOME}/gkwatch/.env.template" "$PACK_DIR/gkwatch-pack/.env"
cp "${HOME}/gkwatch/gkwatch.json" "$PACK_DIR/gkwatch-pack/"
cp "${HOME}/gkwatch/README.md" "$PACK_DIR/gkwatch-pack/"
cp "${HOME}/gkwatch/scripts/build_pack.sh" "$PACK_DIR/gkwatch-pack/scripts/"

# ─── Zip ────────────────────────────────────────────────────
cd "$PACK_DIR"
zip -r "$OUTPUT" gkwatch-pack/ > /dev/null 2>&1

echo "✅ Pack créé : $OUTPUT"
echo "   Taille : $(du -h "$OUTPUT" | cut -f1)"
ls -la "$OUTPUT"

rm -rf "$PACK_DIR"
echo "=== Done ==="
